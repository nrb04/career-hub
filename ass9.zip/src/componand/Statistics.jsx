import React from 'react';

const Statistics = () => {
    return (
        <div>
            baler stat
        </div>
    );
};

export default Statistics;