import React from 'react';
import LazyHome from './babyhome/LazyHome';
import WorkingHome from './babyhome/WorkingHome';
const Home = () => {
    return (
        <div>
           {/* <LazyHome></LazyHome> */}
            <WorkingHome></WorkingHome>
        </div>
    );
};

export default Home;