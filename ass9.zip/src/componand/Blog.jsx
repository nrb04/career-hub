import React from 'react';

const Blog = () => {
    return (
        <div>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestiae, delectus illum explicabo iure officiis necessitatibus totam nam repellendus vel vitae sequi consequuntur consectetur nobis incidunt inventore cupiditate, neque nesciunt voluptatibus!
        </div>
    );
};

export default Blog;